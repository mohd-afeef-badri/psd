## Code of Conduct:

https://en.wikipedia.org/wiki/Golden_Rule

## Scope:

Universal.  When in doubt, assume the rule applies to you as it does to
the most sensitive person you can imagine (your grandmother, perhaps).
Put yourself in their shoes, and then apply the rule to them.  Then
treat that person in the same manner.  This addresses the one major
possible criticism of the Golden Rule
( https://en.wikipedia.org/wiki/Golden_Rule#Criticism )

## Enforcement:

Contact Tim Davis, DrTimothyAldenDavis@gmail.com.  I take this very
seriously.
