#### Deprecation notice

HPDDM is now available in PETSc with the option `--download-hpddm`.  
One may switch to HPDDM iterative methods using `-ksp_type hpddm`, cf. [KSPHPDDM](https://www.mcs.anl.gov/petsc/petsc-dev/docs/manualpages/KSP/KSPHPDDM.html).  
The examples from this folder are deprecated and will not be updated.
